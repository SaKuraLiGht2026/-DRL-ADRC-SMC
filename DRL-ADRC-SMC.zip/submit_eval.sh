#!/bin/bash
#SBATCH --job-name=btest
#SBATCH --partition=shared
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --output=/home/shukai/logs/%j_drl_adrc.out
#SBATCH --error=/home/shukai/logs/%j_drl_adrc.err
#SBATCH --time=1:00:00

source ~/miniconda3/etc/profile.d/conda.sh
conda activate torch310
cd /home/shukai/projects/drl_adrc_robot
python run_eval_only.py
